/**
 * AIToolsModal — AI-powered image tools for DTF Layout builder
 * 
 * Features:
 * - Smart Image Analyzer (auto-detects image type, recommends tool)
 * - AI Enhance (Real-ESRGAN via Replicate: 2x/4x upscale)
 * - Vectorize placeholder (Session 2)
 * 
 * Opens from Toolbox "AI Tools" button. User picks an image, sees analysis,
 * then enhances or vectorizes. Result replaces the original on the canvas.
 */

import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Sparkles,
  Wand2,
  Zap,
  ArrowRight,
  Check,
  X,
  Loader2,
  ChevronLeft,
  Image as ImageIcon,
  Eye,
  ZoomIn,
  ArrowUpRight,
  Info,
  Coins,
  AlertTriangle,
} from "lucide-react";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { useCredits } from "@/contexts/CreditsContext";
import {
  analyzeImage,
  ImageAnalysis,
  AI_TOOL_CREDITS,
  AI_TOOLS_MAX_FILE_SIZE,
} from "@/utils/imageAnalyzerUtils";
import type { ImageObject } from "@/components/CollageCreator";

// ─── Types ───────────────────────────────────────────────────────────

type AIToolStep = 'pick-image' | 'analyze' | 'enhance' | 'result';
type ScaleOption = 2 | 4;

interface AIToolsModalProps {
  isOpen: boolean;
  onClose: () => void;
  images: ImageObject[];
  /** If set, skip image picker and go straight to analysis */
  initialImageId?: string;
  /** Called when an image is enhanced — parent replaces original with result */
  onEnhanceComplete: (imageId: string, newBlobUrl: string, newFile: File) => void;
}

// ─── Component ───────────────────────────────────────────────────────

export const AIToolsModal: React.FC<AIToolsModalProps> = ({
  isOpen,
  onClose,
  images,
  initialImageId,
  onEnhanceComplete,
}) => {
  const { session } = useAuth();
  const { credits, deductCredits, refreshCredits } = useCredits();

  // ── State ──
  const [step, setStep] = useState<AIToolStep>('pick-image');
  const [selectedImage, setSelectedImage] = useState<ImageObject | null>(null);
  const [analysis, setAnalysis] = useState<ImageAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [scale, setScale] = useState<ScaleOption>(4);
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [enhancedUrl, setEnhancedUrl] = useState<string | null>(null);
  const [enhancedBlobUrl, setEnhancedBlobUrl] = useState<string | null>(null);
  const [showOriginal, setShowOriginal] = useState(false);
  const [enhanceError, setEnhanceError] = useState<string | null>(null);

  const abortRef = useRef<AbortController | null>(null);

  // ── Reset on open/close ──
  useEffect(() => {
    if (isOpen) {
      setEnhanceError(null);
      setEnhancedUrl(null);
      setEnhancedBlobUrl(null);
      setShowOriginal(false);
      setIsEnhancing(false);
      setAnalysis(null);
      setScale(4);

      if (initialImageId) {
        const img = images.find(i => i.id === initialImageId);
        if (img) {
          setSelectedImage(img);
          setStep('analyze');
          return;
        }
      }

      if (images.length === 1) {
        setSelectedImage(images[0]);
        setStep('analyze');
      } else {
        setSelectedImage(null);
        setStep('pick-image');
      }
    } else {
      // Cleanup on close
      abortRef.current?.abort();
      if (enhancedBlobUrl) {
        URL.revokeObjectURL(enhancedBlobUrl);
      }
    }
  }, [isOpen]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Auto-analyze when image selected ──
  useEffect(() => {
    if (step === 'analyze' && selectedImage && !analysis && !isAnalyzing) {
      runAnalysis(selectedImage);
    }
  }, [step, selectedImage]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Analysis ──
  const runAnalysis = useCallback(async (image: ImageObject) => {
    setIsAnalyzing(true);
    setAnalysis(null);
    try {
      const result = await analyzeImage(image.url);
      setAnalysis(result);
    } catch (err) {
      console.error('[AITools] Analysis failed:', err);
      // Provide fallback — default to enhance recommendation
      setAnalysis({
        recommendation: 'enhance',
        confidence: 0.3,
        details: {
          uniqueColors: 0,
          flatColorRatio: 0,
          hasTransparency: false,
          semiTransparentRatio: 0,
          edgeSharpness: 0,
          noiseLevel: 0,
          dimensions: { width: 0, height: 0 },
        },
        vectorScore: 0,
        enhanceScore: 50,
        detectedType: 'Unknown',
      });
    }
    setIsAnalyzing(false);
  }, []);

  // ── Enhance ──
  const handleEnhance = useCallback(async () => {
    if (!selectedImage || !session?.access_token) return;

    const creditCost = AI_TOOL_CREDITS.ENHANCE_4X;

    // Check credits
    if (credits < creditCost) {
      toast.error(`Insufficient credits. You need ${creditCost.toLocaleString()} credits.`);
      return;
    }

    // Check file size
    if (selectedImage.file.size > AI_TOOLS_MAX_FILE_SIZE) {
      toast.error('Image exceeds 30MB limit. Please use a smaller image.');
      return;
    }

    setIsEnhancing(true);
    setEnhanceError(null);
    setEnhancedUrl(null);
    setEnhancedBlobUrl(null);

    try {
      // Convert image to base64
      const base64 = await fileToBase64(selectedImage.file);

      // Call API
      abortRef.current = new AbortController();
      const response = await fetch('/api/enhance', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          image: base64,
          scale,
          faceEnhance: false,
        }),
        signal: abortRef.current.signal,
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || 'Enhancement failed');
      }

      // Download the enhanced image from Replicate URL
      const imgResponse = await fetch(data.url);
      if (!imgResponse.ok) throw new Error('Failed to download enhanced image');
      const blob = await imgResponse.blob();
      const blobUrl = URL.createObjectURL(blob);

      setEnhancedUrl(data.url);
      setEnhancedBlobUrl(blobUrl);

      // Deduct credits AFTER successful processing
      const deductResult = await deductCredits(creditCost, `AI Enhance ${scale}x`);
      if (!deductResult.success) {
        console.error('[AITools] Credit deduction failed:', deductResult.error);
        // Don't block — the enhancement already happened
      }

      setStep('result');
      toast.success(`Image enhanced at ${scale}x! ${creditCost} credits used.`);

    } catch (err: any) {
      if (err.name === 'AbortError') return;
      console.error('[AITools] Enhance error:', err);
      setEnhanceError(err.message || 'Enhancement failed. Please try again.');
      toast.error(err.message || 'Enhancement failed');
    } finally {
      setIsEnhancing(false);
    }
  }, [selectedImage, session, scale, credits, deductCredits]);

  // ── Apply result ──
  const handleApplyResult = useCallback(async () => {
    if (!selectedImage || !enhancedBlobUrl) return;

    try {
      const response = await fetch(enhancedBlobUrl);
      const blob = await response.blob();
      const file = new File([blob], `enhanced_${selectedImage.file.name}`, { type: 'image/png' });

      onEnhanceComplete(selectedImage.id, enhancedBlobUrl, file);
      toast.success('Enhanced image applied to canvas');
      onClose();
    } catch (err) {
      console.error('[AITools] Apply failed:', err);
      toast.error('Failed to apply enhanced image');
    }
  }, [selectedImage, enhancedBlobUrl, onEnhanceComplete, onClose]);

  // ── Helpers ──
  const handleSelectImage = (image: ImageObject) => {
    setSelectedImage(image);
    setAnalysis(null);
    setEnhancedUrl(null);
    setEnhancedBlobUrl(null);
    setEnhanceError(null);
    setStep('analyze');
  };

  const handleBack = () => {
    if (step === 'result') {
      setStep('analyze');
    } else if (step === 'analyze' || step === 'enhance') {
      if (images.length > 1) {
        setStep('pick-image');
        setSelectedImage(null);
        setAnalysis(null);
      }
    }
  };

  const creditCost = AI_TOOL_CREDITS.ENHANCE_4X;
  const hasEnoughCredits = credits >= creditCost;

  // ─── Render ────────────────────────────────────────────────────────

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl font-bold tracking-tight flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-indigo-500" />
            AI Image Tools
            <Badge variant="outline" className="ml-2 text-xs bg-indigo-500/10 text-indigo-400 border-indigo-500/20">
              Beta
            </Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto min-h-0 px-1">
          {/* ── Step 1: Pick Image ── */}
          {step === 'pick-image' && (
            <div className="space-y-4">
              <p className="text-sm text-muted-foreground">
                Select an image to analyze and enhance with AI.
              </p>
              <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                {images.map(image => (
                  <button
                    key={image.id}
                    onClick={() => handleSelectImage(image)}
                    className="group relative aspect-square rounded-lg overflow-hidden border-2 border-transparent hover:border-indigo-500 transition-all duration-200 bg-gray-100"
                  >
                    <img
                      src={image.thumbnailUrl}
                      alt="Upload"
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute inset-0 bg-indigo-500/0 group-hover:bg-indigo-500/10 transition-colors flex items-center justify-center">
                      <ArrowRight className="w-5 h-5 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-lg" />
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* ── Step 2: Analysis + Enhance Options ── */}
          {step === 'analyze' && selectedImage && (
            <div className="space-y-5">
              {/* Image preview + analysis */}
              <div className="flex gap-4 items-start">
                {/* Thumbnail */}
                <div className="w-28 h-28 sm:w-36 sm:h-36 flex-shrink-0 rounded-lg overflow-hidden bg-gray-100 border">
                  <img
                    src={selectedImage.thumbnailUrl}
                    alt="Selected"
                    className="w-full h-full object-contain"
                  />
                </div>

                {/* Analysis */}
                <div className="flex-1 min-w-0 space-y-3">
                  {isAnalyzing ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Analyzing image...
                    </div>
                  ) : analysis ? (
                    <>
                      {/* Detected type */}
                      <div>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-indigo-500/15 text-indigo-600 border-0 text-xs">
                            {analysis.detectedType}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {Math.round(analysis.confidence * 100)}% confidence
                          </span>
                        </div>
                      </div>

                      {/* Details row */}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                        <span>{analysis.details.dimensions.width} × {analysis.details.dimensions.height}px</span>
                        <span>{analysis.details.uniqueColors.toLocaleString()} colors</span>
                        <span>Edges: {analysis.details.edgeSharpness > 0.5 ? 'Sharp' : analysis.details.edgeSharpness > 0.2 ? 'Mixed' : 'Soft'}</span>
                        {analysis.details.hasTransparency && <span>Has transparency</span>}
                      </div>

                      {/* Recommendation */}
                      <div className="rounded-lg border bg-indigo-50/50 p-3 mt-2">
                        <div className="flex items-center gap-2 text-sm font-medium text-indigo-700">
                          <Sparkles className="w-4 h-4" />
                          Recommended: {analysis.recommendation === 'enhance' ? 'AI Enhance' : 'Vectorize'}
                        </div>
                        <p className="text-xs text-indigo-600/70 mt-1">
                          {analysis.recommendation === 'enhance'
                            ? 'This looks like a photo or complex artwork. AI enhancement will upscale while preserving detail.'
                            : 'This looks like a logo or illustration. Vectorizing will make it infinitely scalable. (Coming in next update)'}
                        </p>
                      </div>
                    </>
                  ) : null}
                </div>
              </div>

              {/* ── Enhance Card ── */}
              <div className="rounded-xl border bg-white shadow-sm overflow-hidden">
                <div className="p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-full bg-amber-500 flex items-center justify-center">
                        <Zap className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-heading font-bold text-sm">AI Enhance</h3>
                        <p className="text-xs text-muted-foreground">Upscale with Real-ESRGAN</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs">
                      <Coins className="w-3.5 h-3.5 text-amber-500" />
                      <span className="font-medium">{creditCost.toLocaleString()} credits</span>
                    </div>
                  </div>

                  {/* Scale selector */}
                  <div className="space-y-2">
                    <label className="text-xs font-medium text-muted-foreground">Upscale Factor</label>
                    <div className="flex gap-2">
                      {([2, 4] as ScaleOption[]).map(s => (
                        <button
                          key={s}
                          onClick={() => setScale(s)}
                          className={`flex-1 py-2.5 rounded-lg text-sm font-medium transition-all border ${
                            scale === s
                              ? 'border-indigo-500 bg-indigo-50 text-indigo-700 shadow-sm'
                              : 'border-gray-200 bg-white text-gray-600 hover:bg-gray-50'
                          }`}
                        >
                          {s}× Upscale
                          <span className="block text-xs font-normal text-muted-foreground mt-0.5">
                            {selectedImage && analysis
                              ? `${analysis.details.dimensions.width * s} × ${analysis.details.dimensions.height * s}px`
                              : ''}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Transparency warning */}
                  {analysis?.details.hasTransparency && (
                    <div className="flex items-start gap-2 text-xs text-amber-700 bg-amber-50 rounded-lg p-2.5 border border-amber-200/50">
                      <AlertTriangle className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                      <span>
                        This image has transparency. The AI enhancer will process the visible content and preserve the transparent background.
                      </span>
                    </div>
                  )}

                  {/* Error */}
                  {enhanceError && (
                    <div className="flex items-start gap-2 text-xs text-red-700 bg-red-50 rounded-lg p-2.5 border border-red-200/50">
                      <X className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                      <span>{enhanceError}</span>
                    </div>
                  )}

                  {/* Credits check */}
                  {!hasEnoughCredits && (
                    <div className="flex items-start gap-2 text-xs text-red-700 bg-red-50 rounded-lg p-2.5 border border-red-200/50">
                      <Coins className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" />
                      <span>
                        Insufficient credits. You have {credits.toLocaleString()} but need {creditCost.toLocaleString()}.{' '}
                        <a href="/app/billing" className="underline font-medium">Buy credits</a>
                      </span>
                    </div>
                  )}

                  {/* Enhance button */}
                  <Button
                    onClick={handleEnhance}
                    disabled={isEnhancing || !hasEnoughCredits || isAnalyzing}
                    className="w-full bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white shadow-md"
                    size="lg"
                  >
                    {isEnhancing ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Enhancing... (10-30 sec)
                      </>
                    ) : (
                      <>
                        <Zap className="w-4 h-4 mr-2" />
                        Enhance at {scale}×
                      </>
                    )}
                  </Button>
                </div>
              </div>

              {/* ── Vectorize Card (Coming Soon) ── */}
              <div className="rounded-xl border bg-gray-50/50 overflow-hidden opacity-60">
                <div className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="w-9 h-9 rounded-full bg-emerald-500 flex items-center justify-center">
                        <ArrowUpRight className="w-4 h-4 text-white" />
                      </div>
                      <div>
                        <h3 className="font-heading font-bold text-sm">AI Vectorize</h3>
                        <p className="text-xs text-muted-foreground">Convert to infinitely scalable SVG</p>
                      </div>
                    </div>
                    <Badge variant="outline" className="text-xs bg-emerald-500/10 text-emerald-600 border-emerald-500/20">
                      Coming Soon
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-3">
                    Turn any logo or illustration into a crisp vector. Perfect for small images that need to print large.
                  </p>
                </div>
              </div>

              {/* Back button */}
              {images.length > 1 && (
                <button
                  onClick={handleBack}
                  className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground transition-colors"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                  Choose different image
                </button>
              )}
            </div>
          )}

          {/* ── Step 3: Result (Before/After) ── */}
          {step === 'result' && selectedImage && enhancedBlobUrl && (
            <div className="space-y-4">
              {/* Before/After toggle */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-emerald-500" />
                  <span className="text-sm font-medium text-emerald-700">Enhancement complete!</span>
                </div>
                <button
                  onMouseDown={() => setShowOriginal(true)}
                  onMouseUp={() => setShowOriginal(false)}
                  onMouseLeave={() => setShowOriginal(false)}
                  onTouchStart={() => setShowOriginal(true)}
                  onTouchEnd={() => setShowOriginal(false)}
                  className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors px-3 py-1.5 rounded-lg border bg-white hover:bg-gray-50 active:bg-gray-100"
                >
                  <Eye className="w-3.5 h-3.5" />
                  Hold to see original
                </button>
              </div>

              {/* Preview */}
              <div className="relative rounded-xl overflow-hidden border bg-[repeating-conic-gradient(#f3f4f6_0%_25%,#ffffff_0%_50%)] bg-[length:16px_16px] aspect-video flex items-center justify-center">
                <img
                  src={showOriginal ? selectedImage.url : enhancedBlobUrl}
                  alt={showOriginal ? 'Original' : 'Enhanced'}
                  className="max-w-full max-h-full object-contain"
                />
                {/* Label */}
                <div className="absolute top-3 left-3">
                  <Badge variant="outline" className={`text-xs ${showOriginal ? 'bg-gray-900/70 text-white border-0' : 'bg-emerald-500/90 text-white border-0'}`}>
                    {showOriginal ? 'Original' : `Enhanced ${scale}×`}
                  </Badge>
                </div>
              </div>

              {/* Dimension comparison */}
              {analysis && (
                <div className="flex items-center justify-center gap-4 text-xs text-muted-foreground">
                  <span>{analysis.details.dimensions.width} × {analysis.details.dimensions.height}px</span>
                  <ArrowRight className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="font-medium text-foreground">
                    {analysis.details.dimensions.width * scale} × {analysis.details.dimensions.height * scale}px
                  </span>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setStep('analyze');
                    setEnhancedUrl(null);
                    if (enhancedBlobUrl) URL.revokeObjectURL(enhancedBlobUrl);
                    setEnhancedBlobUrl(null);
                  }}
                  className="flex-1"
                >
                  <ChevronLeft className="w-4 h-4 mr-1" />
                  Try Again
                </Button>
                <Button
                  onClick={handleApplyResult}
                  className="flex-1 bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-700 hover:to-violet-700 text-white shadow-md"
                >
                  <Check className="w-4 h-4 mr-1" />
                  Apply to Canvas
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

// ─── Helpers ─────────────────────────────────────────────────────────

function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsDataURL(file);
  });
}

export default AIToolsModal;
