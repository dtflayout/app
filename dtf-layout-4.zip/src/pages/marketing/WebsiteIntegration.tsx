import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import MarketingNav from "@/components/marketing/MarketingNav";

const HF = "'Bricolage Grotesque', sans-serif";
const BF = "'Inter', sans-serif";
const P = "#4F46E5";
const tint = { indigo: "linear-gradient(135deg, #EEF2FF, #E0E7FF)", mint: "linear-gradient(135deg, #ECFDF5, #D1FAE5)", peach: "linear-gradient(135deg, #FFF7ED, #FED7AA)", pink: "linear-gradient(135deg, #FDF2F8, #FCE7F3)" };

function Sq({ top, left, right, bottom, size = 28, rotate = 12 }: any) { const p: any = {}; if (top != null) p.top = top; if (left != null) p.left = left; if (right != null) p.right = right; if (bottom != null) p.bottom = bottom; return <div style={{ position: "absolute", width: size, height: size, borderRadius: size * 0.25, border: "1.5px dashed rgba(79,70,229,0.1)", transform: `rotate(${rotate}deg)`, pointerEvents: "none", ...p }} />; }
function Dots({ o = 0.2 }: { o?: number }) { return <div style={{ position: "absolute", inset: 0, pointerEvents: "none", opacity: o, backgroundImage: "radial-gradient(circle, rgba(79,70,229,0.1) 1px, transparent 1px)", backgroundSize: "32px 32px" }} />; }
function Pill({ children }: any) { return <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "7px 18px", borderRadius: 99, fontSize: 13, fontWeight: 600, fontFamily: BF, background: "#EEF2FF", color: P, border: "1px solid #C7D2FE" }}>{children}</span>; }
function Btn({ children, v = "p", sz = "m", style: sx, onClick }: any) { const pad: any = { s: "10px 24px", m: "14px 34px", l: "17px 42px" }[sz]; const fs: any = { s: 14, m: 15, l: 16 }[sz]; const vars: any = { p: { background: "linear-gradient(135deg,#4F46E5,#7C3AED)", color: "#fff", border: "none", boxShadow: "0 6px 28px rgba(79,70,229,0.28)" }, o: { background: "#fff", color: "#111827", border: "1.5px solid #E5E7EB", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" } }; return <button onClick={onClick} style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", gap: 8, fontFamily: BF, fontWeight: 600, cursor: "pointer", borderRadius: 99, transition: "all 0.25s", padding: pad, fontSize: fs, ...vars[v], ...sx }}>{children}</button>; }
const ic = { chev: <svg width="10" height="6" viewBox="0 0 10 6" fill="none"><path d="M1 1l4 4 4-4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" /></svg> };
function MovingPattern() { return <div style={{ position: "absolute", inset: 0, overflow: "hidden", pointerEvents: "none" }}><div className="orb orb-1" style={{ position: "absolute", width: 600, height: 600, borderRadius: "50%", background: "radial-gradient(circle, rgba(129,140,248,0.4) 0%, rgba(99,102,241,0.12) 40%, transparent 70%)", top: "-15%", left: "-10%", filter: "blur(40px)" }} /><div className="orb orb-2" style={{ position: "absolute", width: 500, height: 500, borderRadius: "50%", background: "radial-gradient(circle, rgba(167,139,250,0.35) 0%, rgba(139,92,246,0.1) 40%, transparent 70%)", top: "15%", right: "-12%", filter: "blur(30px)" }} /><div className="orb orb-3" style={{ position: "absolute", width: 450, height: 450, borderRadius: "50%", background: "radial-gradient(circle, rgba(165,180,252,0.35) 0%, rgba(99,102,241,0.1) 40%, transparent 70%)", bottom: "5%", left: "25%", filter: "blur(35px)" }} /><div className="grid-drift" style={{ position: "absolute", inset: "-50%", width: "200%", height: "200%", opacity: 0.18, backgroundImage: "linear-gradient(rgba(165,180,252,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(165,180,252,0.3) 1px, transparent 1px)", backgroundSize: "80px 80px" }} /></div>; }

const ANIM_CSS = `
@keyframes gradientShift{0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
@keyframes orbFloat1{0%,100%{transform:translate(0,0) scale(1)}25%{transform:translate(60px,40px) scale(1.1)}50%{transform:translate(20px,80px) scale(0.95)}75%{transform:translate(-40px,30px) scale(1.05)}}
@keyframes orbFloat2{0%,100%{transform:translate(0,0) scale(1)}25%{transform:translate(-50px,60px) scale(1.08)}50%{transform:translate(-80px,20px) scale(0.92)}75%{transform:translate(-20px,-40px) scale(1.03)}}
@keyframes orbFloat3{0%,100%{transform:translate(0,0) scale(1)}33%{transform:translate(70px,-30px) scale(1.12)}66%{transform:translate(-30px,-60px) scale(0.9)}}
@keyframes gridDrift{0%{transform:translate(0,0)}100%{transform:translate(60px,60px)}}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-6px)}}
@keyframes colorPulse{0%,100%{box-shadow:0 0 0 0 rgba(255,255,255,0.4)}50%{box-shadow:0 0 0 6px rgba(255,255,255,0)}}
.orb-1{animation:orbFloat1 8s ease-in-out infinite}.orb-2{animation:orbFloat2 10s ease-in-out infinite}.orb-3{animation:orbFloat3 7s ease-in-out infinite}.grid-drift{animation:gridDrift 8s linear infinite}
.hw-card{transition:all 0.3s ease}.hw-card:hover{transform:translateY(-4px);box-shadow:0 16px 40px rgba(0,0,0,0.08)!important}
.hiw-bg{background:linear-gradient(270deg,#E0E7FF,#C7D2FE,#DDD6FE,#C7D2FE,#E0E7FF);background-size:400% 400%;animation:gradientShift 8s ease infinite}
.bento-card{transition:all 0.4s cubic-bezier(0.4,0,0.2,1)}.bento-card:hover{transform:translateY(-8px);box-shadow:0 24px 56px rgba(79,70,229,0.12)!important;border-color:#C7D2FE!important}
.action-bar-demo{transition:all 0.3s ease}.action-bar-demo:hover{box-shadow:0 12px 40px rgba(15,13,46,0.5)!important;transform:translateY(-2px)}
.color-dot{cursor:pointer;transition:all 0.25s ease;border:3px solid transparent}.color-dot:hover{transform:scale(1.15)}.color-dot.active{border-color:#fff;box-shadow:0 0 0 2px rgba(79,70,229,0.6);animation:colorPulse 2s ease infinite}
`;

const BRAND_COLORS = [
  { name: "Indigo", color: "#4F46E5", bg: "#EEF2FF" },
  { name: "Emerald", color: "#059669", bg: "#ECFDF5" },
  { name: "Rose", color: "#E11D48", bg: "#FFF1F2" },
  { name: "Amber", color: "#D97706", bg: "#FFFBEB" },
  { name: "Cyan", color: "#0891B2", bg: "#ECFEFF" },
];

/* ══════════ INTERACTIVE HERO SHOT ══════════ */
function HeroShot({ brandIdx }: { brandIdx: number }) {
  const b = BRAND_COLORS[brandIdx];
  return (
    <div style={{ borderRadius: 16, overflow: "hidden", background: "#fff", border: "1px solid rgba(79,70,229,0.08)", boxShadow: "0 50px 120px rgba(79,70,229,0.12)" }}>
      <div style={{ display: "flex", alignItems: "center", padding: "10px 16px", background: "#FAFBFD", borderBottom: "1px solid #EEF0F4" }}>
        <div style={{ display: "flex", gap: 6, marginRight: 16 }}>{["#FF5F57", "#FFBD2E", "#28C840"].map((c, i) => <div key={i} style={{ width: 11, height: 11, borderRadius: "50%", background: c }} />)}</div>
        <div style={{ flex: 1, height: 28, background: "#F3F4F6", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center" }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2" style={{ marginRight: 6 }}><rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0110 0v4" /></svg>
          <span style={{ fontSize: 12, color: "#9CA3AF", fontWeight: 500, fontFamily: BF }}>yourprint.shop/build-your-gang-sheet</span>
        </div>
      </div>
      <div style={{ background: b.color, padding: "8px 18px", display: "flex", alignItems: "center", justifyContent: "space-between", transition: "background 0.4s" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <div style={{ width: 24, height: 24, borderRadius: 6, background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" /></svg></div>
          <span style={{ fontSize: 13, fontWeight: 700, color: "#fff", fontFamily: HF }}>YourPrint Co.</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <span style={{ fontSize: 11, color: "rgba(255,255,255,0.7)" }}>Sheet: 22" × —</span>
          <span style={{ fontSize: 11, fontWeight: 600, color: b.color, background: "#fff", padding: "4px 14px", borderRadius: 6, transition: "color 0.4s" }}>Add to Cart</span>
        </div>
      </div>
      <div style={{ background: b.bg, padding: "14px 18px 0", fontFamily: BF, transition: "background 0.4s" }}>
        <div style={{ textAlign: "center", marginBottom: 10 }}>
          <h2 style={{ fontFamily: HF, fontSize: 17, fontWeight: 700, color: "#111827", margin: "0 0 2px" }}>Create Your Gang Sheet</h2>
          <p style={{ fontSize: 11, color: "#6B7280", margin: 0 }}>Upload your designs and generate optimized layouts</p>
        </div>
        <div style={{ padding: 2, borderRadius: 12, background: b.color, marginBottom: 6, maxWidth: 480, margin: "0 auto 8px", transition: "background 0.4s" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 14px", background: "#fff", borderRadius: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: 8, background: b.color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "background 0.4s" }}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" /></svg></div>
            <div style={{ flex: 1 }}><div style={{ fontSize: 12, fontWeight: 600, color: "#111827" }}>Drop images here or click to browse</div><div style={{ fontSize: 9, color: "#6B7280" }}>PNG, JPG · Max 25 MB each</div></div>
            <div style={{ padding: "5px 14px", borderRadius: 8, background: b.color, fontSize: 11, color: "#fff", fontWeight: 600, flexShrink: 0, transition: "background 0.4s" }}>Browse</div>
          </div>
        </div>
        <div style={{ display: "flex", gap: 14, justifyContent: "center", marginBottom: 10 }}>
          {[{ l: "Trim", c: b.color }, { l: "Flip", c: "#0EA5E9" }, { l: "Remove BG", c: "#A855F7" }, { l: "Replace", c: "#F59E0B" }, { l: "Text", c: b.color }].map((t, i) => (
            <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", background: t.c, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 3px 10px ${t.c}35`, transition: "background 0.4s" }}><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2.5"><path d="M12 5v14M5 12h14" /></svg></div>
              <span style={{ fontSize: 7, color: "#6B7280", fontWeight: 500 }}>{t.l}</span>
            </div>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 6, marginBottom: 6 }}>
          {["logo_fire.png", "skull_dtf.png", "eagle_back.png", "rose_vine.png"].map((n, i) => (
            <div key={i} style={{ background: "#fff", borderRadius: 8, border: "1px solid #E5E7EB", padding: 6 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 5, marginBottom: 4 }}>
                <div style={{ width: 22, height: 26, borderRadius: 3, background: `linear-gradient(135deg,${["#E74C3C", "#3498DB", "#2ECC71", "#9B59B6"][i]}cc,${["#E74C3C", "#3498DB", "#2ECC71", "#9B59B6"][i]}66)`, flexShrink: 0 }} />
                <div style={{ fontSize: 7, fontWeight: 600, color: "#111827", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{n}</div>
              </div>
              <div style={{ display: "inline-flex", padding: "1px 5px", borderRadius: 99, background: "#DCFCE7", marginBottom: 3 }}><span style={{ fontSize: 6, fontWeight: 700, color: "#16A34A" }}>300 DPI</span></div>
              <div style={{ display: "flex", gap: 3 }}><div style={{ flex: 1 }}><div style={{ fontSize: 5, color: "#9CA3AF", fontWeight: 600 }}>W</div><div style={{ fontSize: 7, fontWeight: 600, color: "#111827", background: "#F9FAFB", padding: "2px 3px", borderRadius: 3, border: "1px solid #E5E7EB" }}>8.2 in</div></div><div style={{ flex: 1 }}><div style={{ fontSize: 5, color: "#9CA3AF", fontWeight: 600 }}>H</div><div style={{ fontSize: 7, fontWeight: 600, color: "#111827", background: "#F9FAFB", padding: "2px 3px", borderRadius: 3, border: "1px solid #E5E7EB" }}>10.5 in</div></div></div>
            </div>
          ))}
        </div>
        <div style={{ padding: "6px 0 10px" }}>
          <div style={{ background: b.color, padding: "9px 16px", display: "flex", alignItems: "center", justifyContent: "space-between", borderRadius: 10, transition: "background 0.4s" }}>
            <span style={{ fontSize: 10, color: "rgba(255,255,255,0.7)" }}>Sheet Width: 22 inches (fixed) · 4 Images</span>
            <div style={{ display: "flex", gap: 6 }}>
              <span style={{ fontSize: 10, fontWeight: 500, color: "rgba(255,255,255,0.8)", padding: "4px 12px", borderRadius: 99, border: "1px solid rgba(255,255,255,0.3)" }}>Preview</span>
              <span style={{ fontSize: 10, fontWeight: 600, color: b.color, padding: "4px 14px", borderRadius: 99, background: "#fff", transition: "color 0.4s" }}>Generate Layout</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function WebsiteIntegration() {
  const navigate = useNavigate();
  const [brandIdx, setBrandIdx] = useState(0);
  const [wlIdx, setWlIdx] = useState(1);
  const [autoCycle, setAutoCycle] = useState(true);
  useEffect(() => { const l1 = document.createElement("link"); l1.href = "https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@400;600;700;800&family=Inter:wght@400;500;600;700&display=swap"; l1.rel = "stylesheet"; document.head.appendChild(l1); return () => { document.head.removeChild(l1); }; }, []);
  useEffect(() => { if (!autoCycle) return; const t = setInterval(() => { setBrandIdx(p => (p + 1) % BRAND_COLORS.length); setWlIdx(p => (p + 1) % BRAND_COLORS.length); }, 2500); return () => clearInterval(t); }, [autoCycle]);
  const pickBrand = (i: number) => { setAutoCycle(false); setBrandIdx(i); };
  const pickWl = (i: number) => { setAutoCycle(false); setWlIdx(i); };

  return (
    <div style={{ fontFamily: BF, color: "#111827", overflowX: "hidden" }}>
      <style>{ANIM_CSS}</style>

      {/* NAV — Exact match from Home/GangSheetBuilder */}
      <MarketingNav />

      {/* HERO */}
      <section style={{ position: "relative", overflow: "hidden", background: "linear-gradient(180deg, #0A0820 0%, #0F0D2E 12%, #1E1B4B 24%, #312E81 36%, #4F46E5 48%, #6366F1 55%, #818CF8 62%, #A5B4FC 68%, #C7D2FE 74%, #E0E7FF 80%, #EEF2FF 86%, #F5F5F7 92%, #FAFAFB 100%)", padding: "0 40px 0" }}>
        <Dots o={0.04} /><MovingPattern />
        <div style={{ padding: "140px 0 0" }}>
          <Sq top={20} right={140} size={32} rotate={18} /><Sq top={100} right={80} size={22} rotate={-12} /><Sq top={30} left={100} size={28} rotate={22} />
          <div style={{ position: "relative", zIndex: 2, maxWidth: 720, margin: "0 auto", textAlign: "center" }}>
            <Pill><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={P} strokeWidth="2" style={{ marginRight: 2 }}><circle cx="12" cy="12" r="10" /><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10A15.3 15.3 0 0 1 12 2z" /></svg> Website Integration</Pill>
            <h1 style={{ fontFamily: HF, fontSize: 60, fontWeight: 800, color: "#fff", lineHeight: 1.08, letterSpacing: "-0.03em", margin: "28px 0 20px" }}>Your Brand. Your Builder.<br />Your Website.</h1>
            <p style={{ fontSize: 17, color: "rgba(255,255,255,0.75)", lineHeight: 1.7, maxWidth: 540, margin: "0 auto 36px" }}>Embed a fully white-labeled gang sheet builder on your own website. Your customers create sheets, you fulfill orders — all under your brand.</p>
            <div style={{ display: "flex", justifyContent: "center", gap: 14 }}>
              <Btn sz="l" onClick={() => navigate("/signup")} style={{ background: "#fff", color: P, boxShadow: "0 6px 28px rgba(0,0,0,0.15)" }}>Start Embedding Free →</Btn>
              <Btn v="o" sz="l" style={{ background: "transparent", color: "#fff", borderColor: "rgba(255,255,255,0.3)", boxShadow: "none" }} onClick={() => navigate("/pricing")}>View Pricing →</Btn>
            </div>
          </div>
          <div style={{ position: "relative", zIndex: 2, maxWidth: 820, margin: "72px auto 0" }}>
            <HeroShot brandIdx={brandIdx} />
            <div style={{ display: "flex", justifyContent: "center", gap: 12, marginTop: 20, marginBottom: 8 }}>
              <span style={{ fontSize: 12, color: "#9CA3AF", fontWeight: 500, alignSelf: "center" }}>Try a brand color:</span>
              {BRAND_COLORS.map((c, i) => <div key={i} className={`color-dot ${brandIdx === i ? "active" : ""}`} onClick={() => pickBrand(i)} style={{ width: 28, height: 28, borderRadius: "50%", background: c.color }} title={c.name}></div>)}
            </div>
          </div>
          <div style={{ height: 120, background: "linear-gradient(180deg, transparent, #FAFAFB)" }} />
        </div>
      </section>

      {/* HOW IT WORKS — Alternating visual cards */}
      <section style={{ padding: "120px 40px", position: "relative" }}><Dots o={0.08} /><Sq top={80} right={120} size={32} rotate={18} /><Sq bottom={90} left={100} size={24} rotate={-15} /><div style={{ maxWidth: 1060, margin: "0 auto", position: "relative", zIndex: 1 }}><div style={{ textAlign: "center", marginBottom: 64 }}><Pill>Quick Setup</Pill><h2 style={{ fontFamily: HF, fontSize: 44, fontWeight: 800, color: "#111827", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "20px 0 12px" }}>Live on Your Website in 3 Steps</h2><p style={{ fontSize: 16, color: "#6B7280", lineHeight: 1.7, maxWidth: 520, margin: "0 auto" }}>No coding. No plugins. Just a link you can embed anywhere.</p></div>
        {/* Step 1 */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 32, marginBottom: 72, alignItems: "center" }}>
          <div><div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}><div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg,#4F46E5,#7C3AED)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 18, fontWeight: 800, fontFamily: HF }}>1</div><h3 style={{ fontFamily: HF, fontSize: 28, fontWeight: 800, color: "#111827", margin: 0 }}>Create Your Store</h3></div><p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.7, margin: "0 0 20px" }}>Pick a store name, upload your logo, and set your unique builder URL. Your embeddable link is generated instantly — ready to paste anywhere.</p><div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{["Store Name", "Custom Logo", "Builder URL", "Subdomain"].map((t, i) => <span key={i} style={{ padding: "6px 14px", borderRadius: 99, fontSize: 12, fontWeight: 600, background: "#EEF2FF", color: P, border: "1px solid #C7D2FE" }}>{t}</span>)}</div></div>
          <div className="bento-card" style={{ background: "#fff", borderRadius: 20, border: "1px solid #E5E7EB", boxShadow: "0 2px 8px rgba(0,0,0,0.02)", overflow: "hidden" }}><div style={{ padding: 20 }}><div style={{ background: tint.indigo, borderRadius: 14, padding: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#111827", marginBottom: 14, fontFamily: HF }}>Store Setup</div>
            {[{ l: "Store Name", v: "YourPrint Co.", w: "100%" }, { l: "Store Slug", v: "yourprint", w: "100%" }].map((f, i) => <div key={i} style={{ marginBottom: 10, width: f.w }}><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, marginBottom: 3, textTransform: "uppercase" }}>{f.l}</div><div style={{ background: "#fff", borderRadius: 8, padding: "8px 12px", border: "1px solid rgba(0,0,0,0.06)", fontSize: 12, fontWeight: 500, color: "#111827" }}>{f.v}</div></div>)}
            <div style={{ display: "grid", gridTemplateColumns: "48px 1fr", gap: 10, alignItems: "center", marginBottom: 10 }}><div style={{ width: 48, height: 48, borderRadius: 10, border: "2px dashed #C7D2FE", display: "flex", alignItems: "center", justifyContent: "center", background: "#fff" }}><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#A5B4FC" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" /></svg></div><div><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, textTransform: "uppercase" }}>Logo</div><div style={{ fontSize: 11, color: P, fontWeight: 600 }}>Upload your logo</div></div></div>
            <div style={{ background: "rgba(79,70,229,0.06)", borderRadius: 10, padding: "10px 14px", border: "1px solid rgba(79,70,229,0.12)" }}><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, marginBottom: 3 }}>YOUR BUILDER URL</div><div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ fontSize: 11, color: P, fontFamily: "monospace", fontWeight: 600 }}>builder.dtflayout.com/yourprint</span><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg></div></div>
          </div></div></div>
        </div>
        {/* Step 2 */}
        <div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 32, marginBottom: 72, alignItems: "center" }}>
          <div className="bento-card" style={{ background: "#fff", borderRadius: 20, border: "1px solid #E5E7EB", boxShadow: "0 2px 8px rgba(0,0,0,0.02)", overflow: "hidden" }}><div style={{ padding: 20 }}><div style={{ background: tint.mint, borderRadius: 14, padding: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#111827", marginBottom: 14, fontFamily: HF }}>Appearance Settings</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8, marginBottom: 14 }}>
              {[{ l: "Top Bar", c: "#4F46E5" }, { l: "Primary", c: "#7C3AED" }, { l: "Action Bar", c: "#312E81" }, { l: "Text", c: "#111827" }, { l: "Background", c: "#F5F5F7" }, { l: "Toolbox", c: "#6366F1" }, { l: "Cards", c: "#FFFFFF" }, { l: "Buttons", c: "#4F46E5" }].map((s, i) => <div key={i} style={{ textAlign: "center" }}><div style={{ width: "100%", height: 28, borderRadius: 6, background: s.c, border: "1px solid rgba(0,0,0,0.08)", marginBottom: 3 }} /><div style={{ fontSize: 7, color: "#6B7280", fontWeight: 600 }}>{s.l}</div></div>)}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <div style={{ background: "#fff", borderRadius: 8, padding: "8px 10px", border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 7, color: "#9CA3AF", fontWeight: 600, marginBottom: 2 }}>FONT</div><div style={{ fontSize: 11, fontWeight: 600, color: "#111827", display: "flex", justifyContent: "space-between" }}>Helvetica {ic.chev}</div></div>
              <div style={{ background: "#fff", borderRadius: 8, padding: "8px 10px", border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 7, color: "#9CA3AF", fontWeight: 600, marginBottom: 2 }}>BUTTON STYLE</div><div style={{ display: "flex", gap: 4 }}>{["Pill", "Rounded", "Square"].map((bb, i) => <span key={i} style={{ padding: "2px 8px", borderRadius: i === 0 ? 99 : i === 1 ? 6 : 2, fontSize: 8, fontWeight: 600, background: i === 0 ? P : "transparent", color: i === 0 ? "#fff" : "#6B7280", border: i > 0 ? "1px solid #E5E7EB" : "none" }}>{bb}</span>)}</div></div>
            </div>
          </div></div></div>
          <div><div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}><div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg,#4F46E5,#7C3AED)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 18, fontWeight: 800, fontFamily: HF }}>2</div><h3 style={{ fontFamily: HF, fontSize: 28, fontWeight: 800, color: "#111827", margin: 0 }}>Customize Everything</h3></div><p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.7, margin: "0 0 20px" }}>Match your brand with 8 independent color zones, 50+ Google Fonts, 3 button styles, and custom logo injection. See changes live in a real-time preview.</p><div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{["8 Color Zones", "50+ Google Fonts", "Button Styles", "Logo & Favicon", "Live Preview", "Tool Toggles"].map((t, i) => <span key={i} style={{ padding: "6px 14px", borderRadius: 99, fontSize: 12, fontWeight: 600, background: "#ECFDF5", color: "#059669", border: "1px solid #A7F3D0" }}>{t}</span>)}</div></div>
        </div>
        {/* Step 3 */}
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1.2fr", gap: 32, alignItems: "center" }}>
          <div><div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}><div style={{ width: 44, height: 44, borderRadius: 12, background: "linear-gradient(135deg,#4F46E5,#7C3AED)", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 18, fontWeight: 800, fontFamily: HF }}>3</div><h3 style={{ fontFamily: HF, fontSize: 28, fontWeight: 800, color: "#111827", margin: 0 }}>Share or Embed</h3></div><p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.7, margin: "0 0 20px" }}>Copy your unique URL and paste it anywhere — your Shopify store, WordPress site, custom website, or even a social media bio link. Customers start building gang sheets immediately, no login required.</p><div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>{["Direct Link", "Any Website", "iFrame Ready", "Zero Auth", "Mobile Responsive"].map((t, i) => <span key={i} style={{ padding: "6px 14px", borderRadius: 99, fontSize: 12, fontWeight: 600, background: "#FFF7ED", color: "#D97706", border: "1px solid #FDE68A" }}>{t}</span>)}</div></div>
          <div className="bento-card" style={{ background: "#fff", borderRadius: 20, border: "1px solid #E5E7EB", boxShadow: "0 2px 8px rgba(0,0,0,0.02)", overflow: "hidden" }}><div style={{ padding: 20 }}><div style={{ background: tint.peach, borderRadius: 14, padding: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#111827", marginBottom: 14, fontFamily: HF }}>Embed Options</div>
            <div style={{ background: "#fff", borderRadius: 10, padding: 12, marginBottom: 10, border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, marginBottom: 4 }}>DIRECT LINK</div><div style={{ display: "flex", alignItems: "center", gap: 6, background: "#F9FAFB", borderRadius: 6, padding: "6px 10px", border: "1px solid #E5E7EB" }}><span style={{ fontSize: 10, color: P, fontFamily: "monospace", flex: 1 }}>builder.dtflayout.com/yourprint/gang-sheet</span><div style={{ padding: "3px 10px", borderRadius: 5, background: P, fontSize: 8, fontWeight: 700, color: "#fff" }}>Copy</div></div></div>
            <div style={{ background: "#fff", borderRadius: 10, padding: 12, marginBottom: 10, border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, marginBottom: 4 }}>IFRAME EMBED</div><div style={{ background: "#1E1B4B", borderRadius: 6, padding: "8px 10px", fontFamily: "monospace", fontSize: 9, color: "#A5B4FC", lineHeight: 1.6, overflow: "hidden" }}>&lt;iframe src="builder.dtflayout.com<br/>/yourprint/gang-sheet" width="100%"<br/>height="800"&gt;&lt;/iframe&gt;</div></div>
            <div style={{ background: "#fff", borderRadius: 10, padding: 12, border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, marginBottom: 4 }}>YOUR WEBSITE</div><div style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{ width: 28, height: 28, borderRadius: 6, background: "#4F46E5", display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" /></svg></div><div style={{ flex: 1 }}><div style={{ fontSize: 10, fontWeight: 600, color: "#111827" }}>Embed on any website</div><div style={{ fontSize: 8, color: "#6B7280" }}>Shopify, WooCommerce, WordPress, or custom</div></div></div></div>
          </div></div></div>
        </div>
      </div></section>

      {/* WHITE-LABEL SHOWCASE */}
      <section style={{ padding: "120px 40px", background: "#FAFAFB", position: "relative" }}><Dots o={0.06} /><div style={{ maxWidth: 1060, margin: "0 auto", position: "relative", zIndex: 1 }}><div style={{ display: "grid", gridTemplateColumns: "1fr 1.15fr", gap: 48, alignItems: "stretch" }}>
        <div style={{ display: "flex", flexDirection: "column" }}><Pill>Full White-Labeling</Pill><h2 style={{ fontFamily: HF, fontSize: 40, fontWeight: 800, color: "#111827", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "20px 0 12px" }}>Your Brand, Down to Every Pixel</h2><p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.7, margin: "0 0 36px" }}>Customize every visual element so the builder feels native to your site. Your customers never see our brand.</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 20, flex: 1 }}>
            {[{ t: "8 Color Zones", d: "Background, top bar, action bar, primary, text, toolbox icons, image cards — all independently customizable.", ic: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={P} strokeWidth="2"><circle cx="13.5" cy="6.5" r="2.5" /><circle cx="6" cy="12" r="2" /><circle cx="18" cy="18" r="2" /><circle cx="12" cy="18" r="2" /></svg> },
              { t: "50+ Google Fonts", d: "Choose from a curated font library or type any Google Font name. Applied across headings and body text.", ic: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={P} strokeWidth="2"><polyline points="4 7 4 4 20 4 20 7" /><line x1="9" y1="20" x2="15" y2="20" /><line x1="12" y1="4" x2="12" y2="20" /></svg> },
              { t: "Custom Logo & Favicon", d: "Upload your logo — it appears in the top bar and as the loading spinner. Favicon auto-injects for branded browser tabs.", ic: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={P} strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" /></svg> },
              { t: "Button Style Picker", d: "Pill, Rounded, or Square — choose the button shape that matches your site's design language.", ic: <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke={P} strokeWidth="2"><rect x="3" y="8" width="18" height="8" rx="4" /></svg> }
            ].map((f, i) => <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}><div style={{ width: 40, height: 40, borderRadius: 10, background: "#EEF2FF", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{f.ic}</div><div><div style={{ fontSize: 15, fontWeight: 700, color: "#111827", marginBottom: 4 }}>{f.t}</div><div style={{ fontSize: 13, color: "#6B7280", lineHeight: 1.6 }}>{f.d}</div></div></div>)}
          </div>
        </div>
        {/* Right — Settings panel with dynamic brand */}
        <div style={{ borderRadius: 20, overflow: "hidden", border: "1px solid #E5E7EB", boxShadow: "0 16px 48px rgba(0,0,0,0.06)", background: "#fff", display: "flex", flexDirection: "column" }}>
          <div style={{ padding: "16px 20px", borderBottom: "1px solid #E5E7EB", display: "flex", alignItems: "center", justifyContent: "space-between" }}><div><div style={{ fontSize: 15, fontWeight: 700, color: "#111827", fontFamily: HF }}>Appearance</div><div style={{ fontSize: 11, color: "#9CA3AF" }}>Customize colors and branding</div></div><div style={{ display: "flex", alignItems: "center", gap: 6 }}><span style={{ fontSize: 11, color: "#9CA3AF" }}>Use Defaults</span><div style={{ width: 36, height: 20, borderRadius: 10, background: "#E5E7EB", position: "relative" }}><div style={{ position: "absolute", top: 2, left: 2, width: 16, height: 16, borderRadius: "50%", background: "#fff", boxShadow: "0 1px 3px rgba(0,0,0,0.15)" }} /></div></div></div>
          <div style={{ padding: 20, flex: 1 }}>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7280", marginBottom: 12 }}>Color Theme</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: 20 }}>
              {[{ l: "Background", c: BRAND_COLORS[wlIdx].bg }, { l: "Top Bar", c: BRAND_COLORS[wlIdx].color }, { l: "Action Bar", c: BRAND_COLORS[wlIdx].color + "cc" }, { l: "Primary", c: BRAND_COLORS[wlIdx].color }, { l: "Text", c: "#134E4A" }, { l: "Toolbox", c: BRAND_COLORS[wlIdx].color }].map((s, i) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 8 }}><div style={{ width: 28, height: 28, borderRadius: 6, background: s.c, border: "1px solid #E5E7EB", flexShrink: 0, transition: "background 0.4s" }} /><div><div style={{ fontSize: 10, fontWeight: 600, color: "#374151" }}>{s.l}</div></div></div>)}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
              <div><div style={{ fontSize: 11, fontWeight: 600, color: "#6B7280", marginBottom: 6 }}>Font Family</div><div style={{ padding: "8px 12px", borderRadius: 8, border: "1px solid #E5E7EB", fontSize: 13, color: "#111827", display: "flex", justifyContent: "space-between", alignItems: "center" }}>Poppins {ic.chev}</div></div>
              <div><div style={{ fontSize: 11, fontWeight: 600, color: "#6B7280", marginBottom: 6 }}>Button Style</div><div style={{ display: "flex", gap: 6 }}>{["Pill", "Rounded", "Square"].map((bb, i) => <span key={i} style={{ padding: "6px 14px", borderRadius: i === 0 ? 99 : i === 1 ? 8 : 4, fontSize: 12, fontWeight: 600, background: i === 1 ? BRAND_COLORS[wlIdx].color : "#F3F4F6", color: i === 1 ? "#fff" : "#6B7280", border: i !== 1 ? "1px solid #E5E7EB" : "none", transition: "background 0.4s" }}>{bb}</span>)}</div></div>
            </div>
            <div style={{ fontSize: 11, fontWeight: 600, color: "#6B7280", marginBottom: 8 }}>Preview</div>
            <div style={{ borderRadius: 12, overflow: "hidden", border: "1px solid #E5E7EB" }}>
              <div style={{ background: BRAND_COLORS[wlIdx].color, padding: "6px 12px", display: "flex", alignItems: "center", justifyContent: "space-between", transition: "background 0.4s" }}><span style={{ fontSize: 11, fontWeight: 700, color: "#fff" }}>PrintHub Co.</span><span style={{ fontSize: 9, fontWeight: 600, color: BRAND_COLORS[wlIdx].color, background: "#fff", padding: "3px 10px", borderRadius: 8, transition: "color 0.4s" }}>Add to Cart</span></div>
              <div style={{ background: BRAND_COLORS[wlIdx].bg, padding: "10px 14px", textAlign: "center", transition: "background 0.4s" }}><div style={{ fontSize: 13, fontWeight: 700, color: "#111827" }}>Create Your Gang Sheet</div><div style={{ fontSize: 9, color: "#6B7280", marginBottom: 8 }}>Upload designs and generate layouts</div><div style={{ display: "flex", gap: 8, justifyContent: "center", marginBottom: 8 }}>{[BRAND_COLORS[wlIdx].color, "#0EA5E9", "#A855F7"].map((c, i) => <div key={i} style={{ width: 24, height: 24, borderRadius: "50%", background: c, transition: "background 0.4s" }} />)}</div><div style={{ background: BRAND_COLORS[wlIdx].color, padding: "6px 0", borderRadius: 8, transition: "background 0.4s" }}><span style={{ fontSize: 9, fontWeight: 600, color: "#fff" }}>Generate Layout</span></div></div>
            </div>
            <div style={{ display: "flex", justifyContent: "center", gap: 10, marginTop: 14 }}>
              <span style={{ fontSize: 11, color: "#9CA3AF", fontWeight: 500, alignSelf: "center" }}>Try:</span>
              {BRAND_COLORS.map((c, i) => <div key={i} className={`color-dot ${wlIdx === i ? "active" : ""}`} onClick={() => pickWl(i)} style={{ width: 24, height: 24, borderRadius: "50%", background: c.color }} title={c.name}></div>)}
            </div>
          </div>
        </div>
      </div></div></section>

      {/* PRODUCT & VARIANT SYSTEM */}
      <section style={{ padding: "120px 40px", position: "relative" }}><Dots o={0.06} /><div style={{ maxWidth: 1060, margin: "0 auto", position: "relative", zIndex: 1 }}><div style={{ textAlign: "center", marginBottom: 64 }}><Pill>Automated Variant Matching</Pill><h2 style={{ fontFamily: HF, fontSize: 44, fontWeight: 800, color: "#111827", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "20px 0 12px" }}>Height-Based Pricing, Automated</h2><p style={{ fontSize: 16, color: "#6B7280", lineHeight: 1.7, maxWidth: 560, margin: "0 auto" }}>Map your product variants to sheet heights. When a customer generates a sheet, we auto-match the right variant and price.</p></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
          <div className="bento-card" style={{ background: "#fff", borderRadius: 24, border: "1px solid #E5E7EB", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.02)" }}><div style={{ padding: 24 }}><div style={{ background: tint.indigo, borderRadius: 16, padding: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#111827", marginBottom: 12, fontFamily: HF }}>Product Setup</div>
            <div style={{ background: "#fff", borderRadius: 10, padding: 12, marginBottom: 8, border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 8, color: "#9CA3AF", fontWeight: 600, marginBottom: 3 }}>PRODUCT URL</div><div style={{ fontSize: 10, color: "#374151", fontFamily: "monospace", background: "#F9FAFB", padding: "5px 8px", borderRadius: 6, border: "1px solid #E5E7EB" }}>yourstore.com/products/gang-sheet</div></div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 8 }}><div style={{ background: "#fff", borderRadius: 8, padding: "8px 10px", border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 7, color: "#9CA3AF", fontWeight: 600 }}>PRODUCT NAME</div><div style={{ fontSize: 10, fontWeight: 600, color: "#111827" }}>DTF Gang Sheet</div></div><div style={{ background: "#fff", borderRadius: 8, padding: "8px 10px", border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 7, color: "#9CA3AF", fontWeight: 600 }}>SHEET WIDTH</div><div style={{ fontSize: 10, fontWeight: 600, color: "#111827" }}>22 inches</div></div></div>
            <div style={{ background: "#fff", borderRadius: 8, padding: "8px 10px", border: "1px solid rgba(0,0,0,0.04)" }}><div style={{ fontSize: 7, color: "#9CA3AF", fontWeight: 600, marginBottom: 2 }}>BUILDER URL</div><div style={{ display: "flex", alignItems: "center", gap: 6 }}><div style={{ fontSize: 9, color: P, fontFamily: "monospace", flex: 1 }}>builder.dtflayout.com/yourprint/gang-sheet</div><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2"><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" /></svg></div></div>
          </div></div><div style={{ padding: "4px 28px 28px" }}><h3 style={{ fontFamily: HF, fontSize: 22, fontWeight: 700, margin: "0 0 8px", color: "#111827" }}>Connect Any Product</h3><p style={{ fontSize: 14, color: "#6B7280", lineHeight: 1.65, margin: 0 }}>Paste your product URL, fetch variants automatically, and get a unique embeddable builder link for each product.</p></div></div>
          <div className="bento-card" style={{ background: "#fff", borderRadius: 24, border: "1px solid #E5E7EB", overflow: "hidden", boxShadow: "0 2px 8px rgba(0,0,0,0.02)" }}><div style={{ padding: 24 }}><div style={{ background: tint.peach, borderRadius: 16, padding: 20 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: "#111827", marginBottom: 12, fontFamily: HF }}>Product Variants</div>
            <div style={{ background: "#fff", borderRadius: 10, overflow: "hidden", border: "1px solid rgba(0,0,0,0.04)" }}>
              <div style={{ display: "grid", gridTemplateColumns: "1.2fr 0.8fr 0.8fr", padding: "6px 10px", background: "#F9FAFB", borderBottom: "1px solid #E5E7EB" }}><span style={{ fontSize: 7, fontWeight: 700, color: "#9CA3AF", textTransform: "uppercase" }}>Variant</span><span style={{ fontSize: 7, fontWeight: 700, color: "#9CA3AF", textTransform: "uppercase" }}>Height</span><span style={{ fontSize: 7, fontWeight: 700, color: "#9CA3AF", textTransform: "uppercase", textAlign: "right" }}>Price</span></div>
              {[{ v: "22×20", h: "20\"", p: "$8" }, { v: "22×30", h: "30\"", p: "$11" }, { v: "22×40", h: "40\"", p: "$14" }, { v: "22×50", h: "50\"", p: "$17" }, { v: "22×60", h: "60\"", p: "$20" }, { v: "22×70", h: "70\"", p: "$23" }].map((r, i) => <div key={i} style={{ display: "grid", gridTemplateColumns: "1.2fr 0.8fr 0.8fr", padding: "6px 10px", borderBottom: i < 5 ? "1px solid #F3F4F6" : "none", alignItems: "center" }}><span style={{ fontSize: 10, fontWeight: 600, color: "#111827" }}>{r.v}</span><span style={{ fontSize: 10, color: "#6B7280" }}>{r.h}</span><span style={{ fontSize: 10, fontWeight: 600, color: "#111827", textAlign: "right" }}>{r.p}</span></div>)}
            </div>
          </div></div><div style={{ padding: "4px 28px 28px" }}><h3 style={{ fontFamily: HF, fontSize: 22, fontWeight: 700, margin: "0 0 8px", color: "#111827" }}>Auto-Match Variants by Height</h3><p style={{ fontSize: 14, color: "#6B7280", lineHeight: 1.65, margin: 0 }}>Customer generates a 22×38.5" sheet? We match the 22×40 variant at $14 and redirect straight to their cart.</p></div></div>
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 0, marginTop: 40 }}>
          {[{ l: "Customer creates sheet", sub: "22\" × 38.5\"", ic: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><polyline points="21 15 16 10 5 21" /></svg> }, { l: "Variant matched", sub: "22×40 → $14", ic: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" /><polyline points="22 4 12 14.01 9 11.01" /></svg> }, { l: "Cart loaded", sub: "One-click checkout", ic: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2"><circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" /><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" /></svg> }].map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center" }}><div style={{ textAlign: "center" }}><div style={{ width: 52, height: 52, borderRadius: 14, background: "linear-gradient(135deg,#4F46E5,#7C3AED)", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 10px", boxShadow: "0 6px 20px rgba(79,70,229,0.25)" }}>{s.ic}</div><div style={{ fontSize: 14, fontWeight: 700, color: "#111827" }}>{s.l}</div><div style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}>{s.sub}</div></div>{i < 2 && <div style={{ width: 80, height: 2, background: "linear-gradient(90deg,#C7D2FE,#4F46E5,#C7D2FE)", margin: "0 8px", marginBottom: 30 }} />}</div>
          ))}
        </div>
      </div></section>

      {/* ORDER DASHBOARD */}
      <section style={{ padding: "120px 40px", background: "#FAFAFB", position: "relative" }}><Dots o={0.06} /><div style={{ maxWidth: 1060, margin: "0 auto", position: "relative", zIndex: 1 }}><div style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr", gap: 48, alignItems: "center" }}>
        <div style={{ borderRadius: 20, overflow: "hidden", border: "1px solid #E5E7EB", boxShadow: "0 16px 48px rgba(0,0,0,0.06)", background: "#fff" }}>
          {/* Period pills */}
          <div style={{ padding: "12px 16px", borderBottom: "1px solid #F3F4F6", display: "flex", alignItems: "center", gap: 6 }}>
            <span style={{ fontSize: 10, color: "#9CA3AF", fontWeight: 500 }}>Period:</span>
            {["Today", "This Week", "Last 7 Days", "All Time"].map((p, i) => <span key={i} style={{ padding: "4px 10px", borderRadius: 8, fontSize: 9, fontWeight: 600, background: i === 3 ? P : "#F3F4F6", color: i === 3 ? "#fff" : "#6B7280" }}>{p}</span>)}
          </div>
          {/* Stats */}
          <div style={{ display: "flex", gap: 0, borderBottom: "1px solid #E5E7EB" }}>{[{ n: "37", l: "Total", c: "#111827" }, { n: "3", l: "Pending", c: "#F59E0B" }, { n: "5", l: "Paid", c: "#16A34A" }, { n: "9", l: "Downloaded", c: "#3B82F6" }].map((s, i) => <div key={i} style={{ flex: 1, padding: "14px 16px", borderRight: i < 3 ? "1px solid #F3F4F6" : "none" }}><div style={{ fontSize: 20, fontWeight: 800, fontFamily: HF, color: s.c }}>{s.n}</div><div style={{ fontSize: 10, color: "#9CA3AF" }}>{s.l}</div></div>)}</div>
          {/* Search + view toggle */}
          <div style={{ padding: "10px 16px 6px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: "#111827", fontFamily: HF }}>Customer Orders</span>
            <div style={{ display: "flex", gap: 4 }}>{["Kanban", "Table"].map((v, i) => <span key={i} style={{ padding: "4px 12px", borderRadius: 8, fontSize: 10, fontWeight: 600, background: i === 0 ? P : "#F3F4F6", color: i === 0 ? "#fff" : "#6B7280" }}>{v}</span>)}</div>
          </div>
          <div style={{ padding: "0 16px 8px" }}><div style={{ background: "#F9FAFB", borderRadius: 8, border: "1px solid #E5E7EB", padding: "6px 10px", display: "flex", alignItems: "center", gap: 6 }}><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#9CA3AF" strokeWidth="2"><circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" /></svg><span style={{ fontSize: 10, color: "#9CA3AF" }}>Search by Design Code...</span></div></div>
          {/* Kanban */}
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, padding: "0 12px 14px" }}>
            {[{ l: "Pending", c: "#F59E0B", bg: "#FFFBEB", n: 3, cards: [{ code: "DTF-SFXHUF", price: "$14", time: "2d 16h" }, { code: "DTF-A3YKGV", price: "$8", time: "2d 1h" }, { code: "DTF-SQYNV9", price: "$17", time: "1d 8h" }] }, { l: "Paid", c: "#16A34A", bg: "#F0FDF4", n: 2, cards: [{ code: "DTF-KM82PL", price: "$20", time: "Paid" }, { code: "DTF-R7WNXE", price: "$11", time: "Paid" }] }, { l: "Downloaded", c: "#3B82F6", bg: "#EFF6FF", n: 2, cards: [{ code: "DTF-V4JTQD", price: "$14", time: "Done" }, { code: "DTF-BGHL03", price: "$23", time: "Done" }] }].map((col, i) => (
              <div key={i} style={{ borderRadius: 12, border: "1px solid #E5E7EB", overflow: "hidden" }}>
                <div style={{ padding: "8px 10px", display: "flex", alignItems: "center", justifyContent: "space-between", background: col.bg }}><div style={{ display: "flex", alignItems: "center", gap: 5 }}><div style={{ width: 7, height: 7, borderRadius: "50%", background: col.c }} /><span style={{ fontSize: 10, fontWeight: 700, color: "#111827" }}>{col.l}</span></div><span style={{ fontSize: 9, fontWeight: 600, color: col.c, background: "#fff", padding: "1px 6px", borderRadius: 99 }}>{col.n}</span></div>
                <div style={{ padding: 6, minHeight: 130, background: `${col.bg}80` }}>{col.cards.map((card, j) => <div key={j} style={{ background: "#fff", borderRadius: 8, padding: "8px 9px", border: "1px solid #E5E7EB", marginBottom: j < col.cards.length - 1 ? 5 : 0 }}><div style={{ fontSize: 9, fontWeight: 700, color: "#111827", fontFamily: "monospace" }}>{card.code}</div><div style={{ display: "flex", justifyContent: "space-between", marginTop: 4 }}><span style={{ fontSize: 8, fontWeight: 600, color: "#111827" }}>{card.price}</span><span style={{ fontSize: 8, color: col.c, fontWeight: 500 }}>{card.time}</span></div></div>)}</div>
              </div>
            ))}
          </div>
        </div>
        <div><Pill>Order Management</Pill><h2 style={{ fontFamily: HF, fontSize: 40, fontWeight: 800, color: "#111827", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "20px 0 12px" }}>Track Every Order, Drag to Fulfill</h2><p style={{ fontSize: 15, color: "#6B7280", lineHeight: 1.7, margin: "0 0 32px" }}>A Kanban board built for DTF workflows. Drag orders from Pending to Paid, download gang sheet files, and track everything with stats and filters.</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>{[{ t: "Drag-and-Drop Workflow", d: "Move orders between columns with a simple drag. Credits auto-deduct on mark-as-paid." }, { t: "Real File Downloads", d: "Download the actual gang sheet PNGs your customers generated — print-ready with embedded DPI metadata." }, { t: "Stats & Date Filters", d: "Filter by date range or quick presets. See totals, pending, paid, and download stats at a glance." }, { t: "10-Day Auto Expiry", d: "Unclaimed orders expire after 10 days. One-click Clear Expired keeps your dashboard clean." }].map((f, i) => <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}><div style={{ width: 8, height: 8, borderRadius: "50%", background: P, marginTop: 6, flexShrink: 0 }} /><div><div style={{ fontSize: 15, fontWeight: 700, color: "#111827", marginBottom: 3 }}>{f.t}</div><div style={{ fontSize: 13, color: "#6B7280", lineHeight: 1.6 }}>{f.d}</div></div></div>)}</div>
        </div>
      </div></div></section>

      {/* WHY WEBSITE INTEGRATION */}
      <section style={{ padding: "120px 40px", background: "linear-gradient(180deg, #0F0D2E, #1E1B4B, #312E81)", position: "relative", overflow: "hidden" }}><MovingPattern /><div style={{ maxWidth: 1060, margin: "0 auto", position: "relative", zIndex: 1 }}><div style={{ textAlign: "center", marginBottom: 64 }}><Pill>Why Switch?</Pill><h2 style={{ fontFamily: HF, fontSize: 44, fontWeight: 800, color: "#fff", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "20px 0 12px" }}>Stop Losing Customers to Manual Workflows</h2><p style={{ fontSize: 16, color: "rgba(255,255,255,0.6)", lineHeight: 1.7, maxWidth: 540, margin: "0 auto" }}>Every customer who has to email you a file is a customer who might not come back.</p></div>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 32, marginBottom: 48 }}>
          <div style={{ background: "rgba(255,255,255,0.92)", borderRadius: 24, border: "1px solid rgba(255,255,255,0.6)", padding: 36, backdropFilter: "blur(20px)", boxShadow: "0 8px 32px rgba(0,0,0,0.12)" }}><div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}><div style={{ width: 40, height: 40, borderRadius: 10, background: "rgba(239,68,68,0.12)", display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#EF4444" strokeWidth="2" strokeLinecap="round"><circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" /></svg></div><div><div style={{ fontSize: 16, fontWeight: 700, color: "#1E1B4B" }}>Without Website Integration</div><div style={{ fontSize: 12, color: "#6B7280" }}>Manual back-and-forth</div></div></div>{["Customer emails design files to you", "You manually create the gang sheet", "Email back a quote based on sheet size", "Customer pays via invoice or bank transfer", "Repeat for every single order"].map((step, i) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}><div style={{ width: 24, height: 24, borderRadius: 99, background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, fontSize: 10, fontWeight: 700, color: "#EF4444" }}>{i + 1}</div><span style={{ fontSize: 14, color: "#374151" }}>{step}</span></div>)}<div style={{ marginTop: 20, padding: 16, borderRadius: 12, background: "rgba(239,68,68,0.06)", border: "1px solid rgba(239,68,68,0.15)", textAlign: "center" }}><div style={{ fontFamily: "monospace", fontSize: 28, fontWeight: 700, color: "#EF4444" }}>Hours per day</div><div style={{ fontSize: 12, color: "#6B7280", marginTop: 4 }}>On repetitive manual work</div></div></div>
          <div style={{ background: "rgba(255,255,255,0.92)", borderRadius: 24, border: "1px solid rgba(99,102,241,0.25)", padding: 36, backdropFilter: "blur(20px)", boxShadow: "0 8px 32px rgba(79,70,229,0.12)" }}><div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 20 }}><div style={{ width: 40, height: 40, borderRadius: 10, background: "rgba(79,70,229,0.1)", display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6366F1" strokeWidth="2" strokeLinecap="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2" /></svg></div><div><div style={{ fontSize: 16, fontWeight: 700, color: "#1E1B4B" }}>With Website Integration</div><div style={{ fontSize: 12, color: "#6B7280" }}>Fully self-service</div></div></div>{["Customer visits your site and creates their own sheet", "Pricing is automatic based on sheet height", "They add to cart and pay through your store", "You get the order + print-ready file in your dashboard", "Works 24/7 — even while you sleep"].map((step, i) => <div key={i} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}><div style={{ width: 24, height: 24, borderRadius: 99, background: "rgba(79,70,229,0.1)", border: "1px solid rgba(99,102,241,0.2)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#6366F1" strokeWidth="2.5"><path d="M5 13l4 4L19 7" /></svg></div><span style={{ fontSize: 14, color: "#374151" }}>{step}</span></div>)}<div style={{ marginTop: 20, padding: 16, borderRadius: 12, background: "rgba(79,70,229,0.06)", border: "1px solid rgba(99,102,241,0.2)", textAlign: "center" }}><div style={{ fontFamily: "monospace", fontSize: 28, fontWeight: 700, color: "#4F46E5" }}>Fully automated</div><div style={{ fontSize: 12, color: "#6B7280", marginTop: 4 }}>Self-service, 24/7, zero effort</div></div></div>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }}>{[{ n: "No Code", l: "Setup required" }, { n: "50+ Fonts", l: "Google Fonts library" }, { n: "Multi-Sheet", l: "Cart integration" }, { n: "24/7", l: "Self-service ordering" }].map((s, i) => <div key={i} style={{ textAlign: "center", padding: "20px 0", borderRadius: 16, background: "rgba(255,255,255,0.88)", border: "1px solid rgba(255,255,255,0.5)", backdropFilter: "blur(16px)", boxShadow: "0 4px 16px rgba(0,0,0,0.08)" }}><div style={{ fontSize: 24, fontWeight: 800, fontFamily: HF, color: P }}>{s.n}</div><div style={{ fontSize: 12, color: "#6B7280", marginTop: 4 }}>{s.l}</div></div>)}</div>
      </div></section>

      {/* TRY LIVE DEMO */}
      <section style={{ padding: "100px 40px", position: "relative" }}>
        <Dots o={0.06} />
        <div style={{ maxWidth: 900, margin: "0 auto", position: "relative", zIndex: 1 }}>
          <div style={{ borderRadius: 28, overflow: "hidden", background: "linear-gradient(140deg, #0f0d2e 0%, #1e1b4b 30%, #312e81 60%, #4338ca 100%)", boxShadow: "0 16px 56px rgba(30,27,75,0.35)", position: "relative" }}>
            <div style={{ position: "absolute", top: -40, right: -40, width: 160, height: 160, borderRadius: "50%", background: "radial-gradient(circle, rgba(129,140,248,0.15) 0%, transparent 70%)" }} />
            <div style={{ position: "absolute", bottom: -30, left: -30, width: 100, height: 100, borderRadius: "50%", background: "radial-gradient(circle, rgba(99,102,241,0.12) 0%, transparent 70%)" }} />
            <div style={{ padding: "48px 48px", display: "flex", alignItems: "center", gap: 40, position: "relative", zIndex: 1 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "5px 14px", borderRadius: 99, background: "rgba(52,211,153,0.12)", border: "1px solid rgba(52,211,153,0.2)", marginBottom: 16 }}>
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#34d399" strokeWidth="2.5"><polygon points="5 3 19 12 5 21 5 3" /></svg>
                  <span style={{ fontSize: 12, fontWeight: 700, color: "#34d399", letterSpacing: "0.05em" }}>INTERACTIVE DEMO</span>
                </div>
                <h2 style={{ fontFamily: HF, fontSize: 32, fontWeight: 800, color: "#fff", lineHeight: 1.15, letterSpacing: "-0.02em", margin: "0 0 12px" }}>See It In Action — With Your Brand</h2>
                <p style={{ fontSize: 15, color: "rgba(255,255,255,0.6)", lineHeight: 1.7, margin: "0 0 24px" }}>Try the live builder demo. Change colors, upload your logo, pick fonts — see exactly how it will look on your website.</p>
                <Btn sz="m" onClick={() => navigate("/demo/builder")} style={{ background: "#fff", color: P, boxShadow: "0 6px 24px rgba(0,0,0,0.15)" }}>Try Live Demo →</Btn>
              </div>
              <div style={{ flex: "0 0 auto", width: 260, height: 200, borderRadius: 16, background: "rgba(255,255,255,0.06)", border: "1px solid rgba(255,255,255,0.1)", display: "flex", flexDirection: "column", overflow: "hidden" }}>
                <div style={{ padding: "6px 10px", background: "#1e293b", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                    <div style={{ width: 16, height: 16, borderRadius: 4, background: "rgba(79,70,229,0.3)" }} />
                    <span style={{ fontSize: 8, fontWeight: 700, color: "#fff" }}>Your Brand</span>
                  </div>
                  <span style={{ fontSize: 6, fontWeight: 600, padding: "2px 8px", borderRadius: 4, background: "#4F46E5", color: "#fff" }}>Add to Cart</span>
                </div>
                <div style={{ flex: 1, background: "#f1f5f9", padding: "8px", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 6 }}>
                  <div style={{ display: "flex", gap: 4 }}>
                    {["#4F46E5", "#0EA5E9", "#A855F7", "#F59E0B"].map((c, i) => <div key={i} style={{ width: 18, height: 18, borderRadius: "50%", background: c }} />)}
                  </div>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 3, width: "80%" }}>
                    {[1, 2, 3].map(i => <div key={i} style={{ height: 24, borderRadius: 3, background: "#fff", border: "1px solid #E5E7EB" }} />)}
                  </div>
                  <div style={{ fontSize: 7, color: "#9CA3AF", fontWeight: 500 }}>Change any color, font, or style</div>
                </div>
                <div style={{ padding: "4px 10px", background: "#1e293b", display: "flex", justifyContent: "flex-end", gap: 3 }}>
                  <span style={{ fontSize: 5, padding: "2px 6px", borderRadius: 3, border: "1px solid rgba(255,255,255,0.2)", color: "rgba(255,255,255,0.5)" }}>Preview</span>
                  <span style={{ fontSize: 5, padding: "2px 6px", borderRadius: 3, background: "#4F46E5", color: "#fff" }}>Generate</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section style={{ padding: "120px 40px", position: "relative", overflow: "hidden" }}><Dots o={0.1} /><Sq top={60} right={160} size={34} rotate={15} /><Sq bottom={60} left={140} size={28} rotate={-20} /><div style={{ maxWidth: 620, margin: "0 auto", textAlign: "center", position: "relative", zIndex: 1 }}><h2 style={{ fontFamily: HF, fontSize: 44, fontWeight: 800, color: "#111827", lineHeight: 1.1, letterSpacing: "-0.03em", margin: "0 0 18px" }}>Ready to Put Your Builder on Your Website?</h2><p style={{ fontSize: 16, color: "#6B7280", lineHeight: 1.7, margin: "0 0 40px" }}>Start with 20,000 sq.inch free. No credit card required. No monthly fees, ever.</p><div style={{ display: "flex", justifyContent: "center", gap: 14 }}><Btn sz="l" onClick={() => navigate("/signup")}>Start Embedding Free →</Btn><Btn v="o" sz="l" onClick={() => navigate("/pricing")}>View Pricing →</Btn></div></div></section>

      {/* FOOTER */}
      <footer style={{ position: "relative", padding: "0 40px 32px", background: "linear-gradient(180deg, #1E1B4B, #0F0D2E)", color: "rgba(165,180,252,0.6)" }}><div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 1, background: "linear-gradient(90deg, transparent 5%, rgba(99,102,241,0.3) 20%, rgba(129,140,248,0.5) 50%, rgba(99,102,241,0.3) 80%, transparent 95%)" }} /><div style={{ paddingTop: 64 }}><div style={{ maxWidth: 1060, margin: "0 auto" }}><div style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 48, marginBottom: 48 }}><div><div style={{ display: "flex", alignItems: "center", gap: 7, marginBottom: 16 }}><div style={{ width: 28, height: 28, borderRadius: 7, background: "#10B981", display: "flex", alignItems: "center", justifyContent: "center" }}><svg width="12" height="12" viewBox="0 0 24 24" fill="#fff"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" /></svg></div><span style={{ fontFamily: HF, fontWeight: 700, fontSize: 15, color: "#fff" }}>DTF Layout</span></div><p style={{ fontSize: 14, lineHeight: 1.7, maxWidth: 260 }}>Smart DTF sheet builder for printers worldwide. Auto-arrange, optimize, and print — all from one platform.</p></div><div><h4 style={{ fontSize: 11, fontWeight: 600, color: "#A5B4FC", marginBottom: 16, letterSpacing: "0.08em", textTransform: "uppercase" }}>Product</h4>{[{l:"Gang Sheet Builder",to:"/product/gang-sheet-builder"},{l:"Website Integration",to:"/product/website-integration"},{l:"Quick Store",to:"/product/quick-store"},{l:"Pricing",to:"/pricing"}].map(item => <Link key={item.l} to={item.to} style={{ fontSize: 14, marginBottom: 10, display: "block", color: "inherit", textDecoration: "none" }}>{item.l}</Link>)}</div><div><h4 style={{ fontSize: 11, fontWeight: 600, color: "#A5B4FC", marginBottom: 16, letterSpacing: "0.08em", textTransform: "uppercase" }}>Company</h4>{[{l:"FAQ",to:"/faq"},{l:"Contact",to:"/contact"},{l:"Blog",to:"/"}].map(item => <Link key={item.l} to={item.to} style={{ fontSize: 14, marginBottom: 10, display: "block", color: "inherit", textDecoration: "none" }}>{item.l}</Link>)}</div><div><h4 style={{ fontSize: 11, fontWeight: 600, color: "#A5B4FC", marginBottom: 16, letterSpacing: "0.08em", textTransform: "uppercase" }}>Legal</h4>{[{l:"Privacy Policy",to:"/privacy-policy"},{l:"Terms & Conditions",to:"/terms-conditions"},{l:"Refund Policy",to:"/refund-policy"}].map(item => <Link key={item.l} to={item.to} style={{ fontSize: 14, marginBottom: 10, display: "block", color: "inherit", textDecoration: "none" }}>{item.l}</Link>)}</div></div><div style={{ borderTop: "1px solid rgba(99,102,241,0.12)", paddingTop: 24, display: "flex", justifyContent: "space-between", alignItems: "center" }}><span style={{ fontSize: 13 }}>© 2026 DTF Layout · Data Canvas Tech. All rights reserved.</span><span style={{ fontSize: 13, cursor: "pointer" }}>dtflayout@gmail.com</span></div></div></div></footer>
    </div>
  );
}
