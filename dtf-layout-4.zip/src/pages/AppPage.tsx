import { CollageCreator } from "@/components/CollageCreator";
import { AppLayout } from "@/components/AppLayout";

const AppPage = () => {
  return (
    <AppLayout>
      <div className="p-6 bg-transparent">
        <CollageCreator />
      </div>
    </AppLayout>
  );
};

export default AppPage;
