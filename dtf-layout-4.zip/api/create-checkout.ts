import { applyRateLimit, paymentLimiter } from './lib/rateLimit.js';
import { initSentry, Sentry } from './lib/sentry.js';
import type { VercelRequest, VercelResponse } from '@vercel/node';
import DodoPayments from 'dodopayments';
import { createClient } from '@supabase/supabase-js';

// ── Supabase anon client for JWT verification ─────────────────────────
const getAnonClient = () => {
  const supabaseUrl = process.env.SUPABASE_URL || process.env.VITE_SUPABASE_URL;
  const supabaseAnonKey = process.env.SUPABASE_ANON_KEY || process.env.VITE_SUPABASE_ANON_KEY;
  if (!supabaseUrl) throw new Error('Missing SUPABASE_URL');
  if (!supabaseAnonKey) throw new Error('Missing SUPABASE_ANON_KEY');
  return createClient(supabaseUrl, supabaseAnonKey);
};

// ── Product mapping: plan_id → Dodo product_id ────────────────────────────
// India products are served to IN users, global products to everyone else.
// The frontend sends `region: 'india' | 'global'` based on IP detection.

const PRODUCT_MAP: Record<string, { india: string; global: string; credits: number }> = {
  starter: {
    india:  'pdt_0NbAZg2ZiDFl8o4J1Ovfa',  // DTF Starter-India ₹1,999
    global: 'pdt_0NcfnbgcoWVV5ABkqfd4W',  // DTF Starter $49 (new, replaces broken pdt_0NbAW1mIzcAq3bTjhkZj1)
    credits: 150000,
  },
  growth: {
    india:  'pdt_0NbAZtngV3jovZnpXe4WU',  // DTF Growth-India ₹5,999
    global: 'pdt_0NbAWS876LqMRwSFSpDBJ',  // DTF Growth $149
    credits: 500000,
  },
  max: {
    india:  'pdt_0NbAa1eGihyujWptwRpf1',  // DTF Max-India ₹11,999
    global: 'pdt_0NbAXNyhPnjF6NOFWU3AV',  // DTF Max $299
    credits: 2000000,
  },
};

interface CreateCheckoutRequest {
  plan_id: string;         // 'starter' | 'growth' | 'max'
  region: string;          // 'india' | 'global'
  user_email: string;
  user_name?: string;
  user_id: string;
}

// Validate and return CORS origin, or null if not allowed
function getAllowedOrigin(req: VercelRequest): string | null {
  const origin = req.headers.origin;
  if (!origin) return null;
  if (origin === 'https://dtflayout.com' || origin === 'http://localhost:5173') return origin;
  if (/^https:\/\/[\w-]+\.dtflayout\.com$/.test(origin)) return origin;
  return null;
}

export default async function handler(req: VercelRequest, res: VercelResponse) {
  initSentry();

  // CORS headers
  const allowedOrigin = getAllowedOrigin(req);
  if (allowedOrigin) {
    res.setHeader('Access-Control-Allow-Origin', allowedOrigin);
    res.setHeader('Vary', 'Origin');
  }
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    if (!allowedOrigin) return res.status(403).json({ error: 'Origin not allowed' });
    return res.status(200).end();
  }
  if (await applyRateLimit(req, res, paymentLimiter)) return;
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // ── Validate JWT instead of trusting client-supplied user_id ──
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, error: 'Missing authorization token' });
    }

    const token = authHeader.replace('Bearer ', '');
    const anonClient = getAnonClient();
    const { data: { user }, error: authError } = await anonClient.auth.getUser(token);

    if (authError || !user) {
      console.error('[Create Checkout] Auth error:', authError?.message);
      return res.status(401).json({ success: false, error: 'Invalid or expired token' });
    }

    const { plan_id, region, user_name } = req.body as CreateCheckoutRequest;

    // Use JWT-verified values — never trust client-supplied user_id/email
    const user_id = user.id;
    const user_email = user.email || '';

    console.log('[Create Checkout] Authenticated request:', {
      plan_id,
      region,
      has_email: !!user_email,
    });

    // Validate required fields
    if (!plan_id || !region) {
      return res.status(400).json({
        success: false,
        error: 'Missing required fields (plan_id, region)',
      });
    }

    // Validate plan exists
    const plan = PRODUCT_MAP[plan_id];
    if (!plan) {
      return res.status(400).json({
        success: false,
        error: `Invalid plan_id: ${plan_id}. Valid plans: ${Object.keys(PRODUCT_MAP).join(', ')}`,
      });
    }

    // Validate region
    if (region !== 'india' && region !== 'global') {
      return res.status(400).json({
        success: false,
        error: 'Invalid region. Must be "india" or "global".',
      });
    }

    // Get the correct product_id for the region
    let productId = plan[region as 'india' | 'global'];

    // Check API key
    const apiKey = process.env.DODO_PAYMENTS_API_KEY;
    if (!apiKey) {
      console.error('[Create Checkout] DODO_PAYMENTS_API_KEY not configured');
      return res.status(500).json({
        success: false,
        error: 'Payment system not configured',
      });
    }

    // Determine environment — use test_mode unless DODO_LIVE_MODE is explicitly set
    const isLive = process.env.DODO_LIVE_MODE === 'true';

    // In test mode, override with test product ID (live products don't exist in test env)
    const TEST_PRODUCT_ID = process.env.DODO_TEST_PRODUCT_ID || 'pdt_0NbB4gGZZa0PUdOs8zDEA';
    if (!isLive) {
      productId = TEST_PRODUCT_ID;
    }

    // Create Dodo Payments client
    const client = new DodoPayments({
      bearerToken: apiKey,
      environment: isLive ? 'live_mode' : 'test_mode',
    });

    // Build return URL — user lands here after payment
    const baseUrl = process.env.VERCEL_ENV === 'production'
      ? 'https://dtflayout.com'
      : (req.headers.origin || 'https://dtflayout.com');
    const returnUrl = `${baseUrl}/app/payment-success`;

    console.log('[Create Checkout] Creating Dodo checkout session:', {
      product_id: productId,
      region,
      return_url: returnUrl,
      environment: isLive ? 'live' : 'test',
    });

    // Create checkout session via Dodo SDK
    const session = await client.checkoutSessions.create({
      product_cart: [{ product_id: productId, quantity: 1 }],
      customer: {
        email: user_email,
        name: user_name || user_email.split('@')[0],
      },
      return_url: returnUrl,
      metadata: {
        user_id: user_id,
        plan_id: plan_id,
        region: region,
        credits: String(plan.credits),
      },
    });

    console.log('[Create Checkout] Session created successfully:', {
      session_id: session.session_id,
      has_checkout_url: !!session.checkout_url,
    });

    return res.status(200).json({
      success: true,
      checkout_url: session.checkout_url,
      session_id: session.session_id,
    });
  } catch (error: any) {
    console.error('[Create Checkout] Unexpected error:', error);
    Sentry.captureException(error);
    return res.status(500).json({
      success: false,
      error: 'Failed to create checkout session',
    });
  }
}
